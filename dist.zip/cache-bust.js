// Force cache bust - 2025-08-02-23:25
console.log('🚀 Cache bust active - v1.0.2');