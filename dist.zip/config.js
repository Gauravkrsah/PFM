// Production configuration
window.APP_CONFIG = {
  API_BASE_URL: 'https://pfm-xi.vercel.app',
  ENVIRONMENT: 'production'
};